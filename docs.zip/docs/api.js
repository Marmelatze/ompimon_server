YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "Ompimon.Auth.Auth",
        "Ompimon.Backend.User.User",
        "Ompimon.Client.Client",
        "Ompimon.Cluster.BufferStack",
        "Ompimon.Cluster.Client",
        "Ompimon.Cluster.Worker",
        "Ompimon.Monitor.Monitor",
        "Ompimon.Protocol.Application",
        "Ompimon.Protocol.ClientAction.Abort",
        "Ompimon.Protocol.ClientAction.Action",
        "Ompimon.Protocol.ClientAction.AppDetail",
        "Ompimon.Protocol.ClientAction.Applications",
        "Ompimon.Protocol.ClientAction.Counter",
        "Ompimon.Protocol.ClientAction.CounterDetail",
        "Ompimon.Protocol.ClientAction.Login",
        "Ompimon.Protocol.ClientAction.Restart",
        "Ompimon.Protocol.ClientAction.Send",
        "Ompimon.Protocol.ClientAction.SendDetail",
        "Ompimon.Protocol.ClientAction.Sleep",
        "Ompimon.Protocol.ClusterAction.Action",
        "Ompimon.Protocol.ClusterAction.Data",
        "Ompimon.Protocol.ClusterAction.DataDetail",
        "Ompimon.Protocol.ClusterAction.Finalize",
        "Ompimon.Protocol.ClusterAction.Init",
        "Ompimon.Protocol.ClusterAction.SendDetail",
        "Ompimon.Protocol.ClusterAction.TotalCounter",
        "Ompimon.Protocol.ClusterAction.TotalSend",
        "Ompimon.Protocol.Globals",
        "Ompimon.Protocol.Parser",
        "Ompimon.Protocol.Protocol",
        "Ompimon.Storage.Storage"
    ],
    "modules": [
        "ompimon",
        "ompimon-auth",
        "ompimon-backend",
        "ompimon-clien",
        "ompimon-client",
        "ompimon-cluster",
        "ompimon-monitor",
        "ompimon-protocol",
        "ompimon-storage"
    ],
    "allModules": [
        {
            "displayName": "ompimon",
            "name": "ompimon"
        },
        {
            "displayName": "ompimon-auth",
            "name": "ompimon-auth",
            "description": "Authentication class"
        },
        {
            "displayName": "ompimon-backend",
            "name": "ompimon-backend",
            "description": "Manage Users"
        },
        {
            "displayName": "ompimon-clien",
            "name": "ompimon-clien",
            "description": "Stupid websocket testclient"
        },
        {
            "displayName": "ompimon-client",
            "name": "ompimon-client",
            "description": "Represents a client connected to the server.\nMaintains one redis connection per client.\n\n## Redis ##\n\nA connected client listens to incomming requests via redis publish/subscribe for real time data on the channel `client:app:<appId>`.\nMessages are transmitted in JSON format.\n\nPossible messages on this channel are:\n\n**restart**:\nWill be received, when a finalized app is started again.\n\n    {\n       \"action\": \"restart\"\n    }\n\n**finalize**:\nWill be received, when a app gets finalized\n\n    {\n       \"action\": \"finalize\"\n    }"
        },
        {
            "displayName": "ompimon-cluster",
            "name": "ompimon-cluster",
            "description": "Holds buffers received by a client for later parsing."
        },
        {
            "displayName": "ompimon-monitor",
            "name": "ompimon-monitor",
            "description": "Sends current activities to the backend over redis publish/subscribe.\nOnly active when monitor: true is set in config.json"
        },
        {
            "displayName": "ompimon-protocol",
            "name": "ompimon-protocol",
            "description": "Protocol Module handles incomming requests on both sides, client and cluster\n\nCluster Actions:\n\n* {{#crossLink \"Ompimon.Protocol.ClusterAction.Init\"}}0x01: Init{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClusterAction.Data\"}}0x02: Data{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClusterAction.DataDetail\"}}0x03: DataDetail{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClusterAction.TotalSend\"}}0x04: TotalSend{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClusterAction.SendDetail\"}}0x05: SendDetail{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClusterAction.TotalCounter\"}}0x06: TotalCounter{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClusterAction.Finalize\"}}0xFF: Finalize{{/crossLink}}\n\nClient Actions:\n\n* {{#crossLink \"Ompimon.Protocol.ClientAction.Login\"}}0x01: Login{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClientAction.Applications\"}}0x02: Applications{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClientAction.AppDetail\"}}0x03: AppDetail{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClientAction.Counter\"}}0x04: Counter{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClientAction.CounterDetail\"}}0x05: CounterDetail{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClientAction.Send\"}}0x06: Send{{/crossLink}}\n* {{#crossLink \"Ompimon.Protocol.ClientAction.SendDetail\"}}0x07: SendDetail{{/crossLink}}"
        },
        {
            "displayName": "ompimon-storage",
            "name": "ompimon-storage",
            "description": "Storage class for handling communication with the redis db\n\n## Publish / Subscribe ##\nThe communication between server process nodes and client process\nnodes is done via redis publish / subscribe.\n\n## Channels ##\n\n### Cluster ###\nPattern: `cluster:app:<appId>:action`\n\nThis channel is used to make requests from clients to the cluster.\nMessages are encoded JSON objects.\n\nAvailable actions:\n\n* abort\n* restart\n* dataDetail\n\n#### abort ####\nAborts the running app. Is handled by {{#crossLink \"Ompimon.Protocol.Application/abort:method\"}}{{/crossLink}}.\nWill send `<0xFF 0x00>` to node 0.\n\n### restart ###\nRestarts the running app. Is handled by {{#crossLink \"Ompimon.Protocol.Application/restart:method\"}}{{/crossLink}}\nWill send `<0xFE 0x00>` to node 0.\n\n### dataDetail ###\nRequest more data which is not included in regular data.\nThis message will add or remove a listener for specific data. The cluster will only be queried if a listener exists.\nIs handled by {{#crossLink \"Ompimon.Protocol.Application/handleDataRequest:method\"}}{{/crossLink}}\n\nExample messages:\n\n**Add a new listener:**\n\n    {\n       type: \"listen\",\n       sendId: null, // id of the send function. null for all functions {Integer|null},\n       rank: null // rank id. null for all ranks {Integer|null}\n    }\n\n**Remove the same listener:**\n\n    {\n       type: \"stop\",\n       sendId: null,\n       rank: null\n    }\n\n\n### Client ###\n\nPattern: `client:app:<appId>`\n\nThis channel is used to make requests from the cluster to the clients.\nMessages are encoded via JSON.\n\n#### Control Messages ####\nThere are two control messages: *finalize* and *restart*.\n\n*finalize* is send when the current app is finalized.\n\n\n    {\n        \"action\": \"finalize\"\n    }\n\n*restart* is send when the current app is started again.\n\n    {\n        \"action\": \"restart\"\n    }\n\n#### Data Messages ####\nThis messages are send when new data from the cluster is inserted in the db to send real time data to the clients.\n\nEach message has a `type` key, which can be `counter` or `send` to differentiate data from counter and send functions.\n\n##### counter #####\n\n    {\n        \"type\": \"counter\",\n        \"funcName\": \"barrier\", // name of counter function\n        \"rank\": 1, // number of rank\n        \"value\": 123455, // counter value\n        \"timestamp\": 1237575 // time in milliseconds since 1.1.1970\n    }\n\n##### send #####\n\n    {\n        \"type\": \"send\",\n        \"funcName\": \"send\", // send function name\n        \"rank\": 2, // sending rank id\n        \"toRank\": 5, // receiving rank id\n        \"counter\": 1019622, // number of calls\n        \"size\": 4508, // transmitted bytes\n        \"timestamp\": 1371483838514 // time in milliseconds since 1.1.1970\n    }\n\n### App ###\nPattern: `app:<appId>`.\n\nThis channel is used for communiction between differen cluster server processes. The state of an\n{{#crossLink \"Ompimon.Protocol.Application\"}}application{{/crossLink}}\nis maintained on each cluster server process with a connected cluster client.\n\nMessages are encoded via JSON.\n\nAvailable actions:\n\n* send\n* finalize\n\n#### send ####\nWill send a message to all or to selected cluster clients running this application.\n\n\n    {\n       action: 'send',\n       to: 'all', // all or the rank id\n       message: '...' // Buffer with message to send\n    }\n\n#### finalize ####\nSend when the application is finalized.\n\n    {\n       action: 'finalize'\n    }"
        }
    ]
} };
});