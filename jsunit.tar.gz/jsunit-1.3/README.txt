This is JsUnit, a JavaScript unit test framework. JsUnit is a JavaScript 
port of JUnit.

Additionally it contains a Maven 2 Plugin and an Ant Task for JsUnit.

The framework contains also the Perl script js2doxy.pl that supports Javadoc
like comments in JavaScript code.

See LICENSE.txt for license information.

See jsunit/docs/index.html for further information especially on the related 
pages.

